[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/x9tT2GbG)
# Projeto Final de PCS3335 - LabDigi A, 2023

## 1) Descrição
12551769 - Isabella Sadakata Takara  (gerente)<p>
11910490 - Mario Giovanni de Luca Afonso Marszalek<p>
12555627 - Joao de Souza Bortolace<p>
12624457 - Pedro Augusto Evangelista Nardi<p>

Nome curto: SSTV Criptografada<p>
Endereço GIT: [https://classroom.github.com/a/x9tT2GbG](https://github.com/PCS-Poli-USP/projeto-final-projeto-2/)

## 2) Motivação
Introduzida em 1957, a televisão de varredura lenta é um método de transmissão de imagens. Sua utilidade principal consiste na possibilidade de transmitir imagens em canais de banda reduzida - enquanto a televisão analógica transmite 30 quadros por segundo, ocupando 6 MHz de banda, um quadro em SSTV ocupa 3 kHz de banda. Historicamente, isso fez a SSTV protagonista de muitos momentos transmitidos remotamente, como as imagens da lua recebidas da sonda Luna 3, em 1959, e as imagens de Yuri Gagarin, em 1961. 
<p>
Nos dias atuais, a SSTV é utilizada principalmente por radioamadores, com transmissões constantes por parte destes, além de eventuais transmissões espaciais, como as de comemoração por parte da Estação Espacial Internacional. Tamanha carga histórica motivou este grupo a implementar um decodificador análogo a televisão de varredura lenta, visando a transmissão de imagens e sua consequente decodificação e exibição. 

## 3) Revisão
Muitos projetos envolvendo partes similares podem ser encontrados online, mas nenhum deles representa o projeto em sua integralidade. Podemos dividir o projeto em várias partes: implementação da criptografia, lógica de decodificação de sinal, decodificação de imagem e exibição no display VGA. Temos aqui uma implementação da criptografia blowfish. A lógica de decodificação do SSTV - que é uma transmissão de imagem por ondas de rádio, muito utilizada por radioamadores - normalmente depende de Software Defined Radios ou aparelhos de rádio comuns, acoplados a um computador, que realiza a decodificação de imagem. Os receptores SDR estão disponíveis livremente online. Quanto à decodificação de imagem, nesse repositório pode ser encontrado um projeto em FPGA com esta função. Por fim, a exibição no display VGA em FPGAs é algo extremamente comum, com exemplos presentes em diversos tutoriais online - nesse, por exemplo.

## 4) Arquitetura
![image](https://github.com/PCS-Poli-USP/projeto-final-projeto-2/assets/134747227/1aaaa868-9462-4241-a36e-137f4070f464)

## 5) Cronograma
Primeira entrega:<p>
  .Transmissor<p>
    -Módulo de leitura via microSD (provinda da bancada de Lucas Giaconne)<p>
    -Memória RAM com leitura e escrita<p>
    -Codificação via serial, em padrão previamente estabelecido pelo grupo<p>
    -Exceto criptografia<p>
  .Receptor<p>
    -Decodificação do sinal serial<p>
    -Memória RAM com leitura e escrita<p>
    -Comunicação VGA<p>
    -Exceto criptografia<p>
      <p>
 Segunda entrega:<p>
      -Todos os itens da primeira entrega e hardware de criptografia, tanto no transmissor, quanto no receptor<p>
      -Testes e depuração<p>
        <p>
O passo a passo pode ser encontrado no Notion do projeto, em  https://shorturl.at/ntyBM


